import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode.react';

const STOPS = [
  { id: 'CBD', name: 'Nairobi CBD', fareToEnd: 80 },
  { id: 'WEST', name: 'Westlands', fareToEnd: 60 },
  { id: 'KANG', name: 'Kangemi', fareToEnd: 40 },
  { id: 'UDH', name: 'Udhiru', fareToEnd: 20 }
];

export default function Home(){
  const [busIdx, setBusIdx] = useState(0);
  const [selectedBoarding, setSelectedBoarding] = useState('CBD');
  const [ticket, setTicket] = useState(null);
  const [activeTripId, setActiveTripId] = useState(null);

  useEffect(()=>{
    const iv = setInterval(()=>setBusIdx(i=> (i+1)%STOPS.length),7000);
    return ()=>clearInterval(iv);
  },[]);

  function createTrip(){
    const id = 'TRIP_' + Date.now().toString(36);
    setActiveTripId(id);
    alert('Trip created: ' + id);
  }

  function calculateFare(boardingId){
    const boardIdx = STOPS.findIndex(s=>s.id===boardingId);
    const currIdx = busIdx;
    const fare = Math.max(10, STOPS[boardIdx].fareToEnd - STOPS[currIdx].fareToEnd);
    return fare;
  }

  function completePayment(method){
    const fare = calculateFare(selectedBoarding);
    const txId = 'TX_' + Date.now().toString(36);
    setTicket({txId, tripId: activeTripId || 'TRIP-DEMO', boarding: selectedBoarding, amount: fare, time: new Date().toISOString()});
    alert('Payment successful (sim): KES ' + fare);
  }

  return (
    <div style={{padding:24,fontFamily:'sans-serif'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h1>JOO Pay — Passenger</h1>
        <a href="/admin">Admin</a>
      </header>
      <main style={{display:'flex',gap:20,marginTop:20}}>
        <div style={{width:320,background:'#fff',padding:16,borderRadius:12,boxShadow:'0 6px 20px rgba(0,0,0,0.06)'}}>
          <button onClick={createTrip} style={{background:'#059669',color:'#fff',padding:10,borderRadius:8}}>Generate Trip QR</button>
          <div style={{marginTop:12}}>Active Trip QR:</div>
          <div style={{marginTop:8}}>{activeTripId ? <QRCode value={activeTripId} size={140}/> : 'No active trip'}</div>
          <div style={{marginTop:12,fontSize:12,color:'#666'}}>Bus at: <strong>{STOPS[busIdx].name}</strong></div>
        </div>

        <div style={{flex:1,background:'#fff',padding:16,borderRadius:12}}>
          <h3>Board & Pay</h3>
          <div style={{display:'flex',gap:12,marginTop:12}}>
            {STOPS.map(s=>(
              <button key={s.id} onClick={()=>setSelectedBoarding(s.id)} style={{padding:10,background:selectedBoarding===s.id?'#ecfccb':'#f8fafc',borderRadius:8}}>{s.name}<div style={{fontSize:12,color:'#666'}}>Base: KES {s.fareToEnd}</div></button>
            ))}
          </div>

          <div style={{marginTop:16}}>
            <div style={{fontSize:12,color:'#666'}}>Fare:</div>
            <div style={{fontSize:22,fontWeight:700}}>KES {calculateFare(selectedBoarding)}</div>
            <div style={{marginTop:12,display:'flex',gap:8}}>
              <button onClick={()=>completePayment('card')} style={{padding:10,background:'#6366f1',color:'#fff',borderRadius:8}}>Swipe Card (Sim)</button>
              <button onClick={()=>completePayment('mpesa')} style={{padding:10,background:'#f59e0b',borderRadius:8}}>M-Pesa (Sim)</button>
              <button onClick={()=>completePayment('paybill')} style={{padding:10,background:'#374151',color:'#fff',borderRadius:8}}>Paybill (Sim)</button>
            </div>
          </div>

          {ticket && (
            <div style={{marginTop:16,background:'#ecfccb',padding:12,borderRadius:8}}>
              <div><strong>Ticket:</strong> {ticket.txId}</div>
              <div>Trip: {ticket.tripId}</div>
              <div>Boarding: {ticket.boarding}</div>
              <div>Amount: KES {ticket.amount}</div>
              <div style={{fontSize:12,color:'#555'}}>Time: {new Date(ticket.time).toLocaleString()}</div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
