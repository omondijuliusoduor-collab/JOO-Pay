# JOO Pay — Capacitor + Next.js (Codemagic-ready)

This package contains the JOO Pay web app (passenger + admin flows), Capacitor config, sample data, and an `android/` scaffold.
It is configured with a Codemagic workflow to produce a Debug APK automatically.

Created: 2025-09-30

Quick test (web):
1. cd web
2. npm install
3. npm run dev
4. Open http://localhost:3000 (Passenger) and http://localhost:3000/admin (Admin)

To build APK locally (Android Studio required):
1. npm run build (from repo root)
2. npx cap add android
3. npx cap copy android
4. Open the `android/` folder in Android Studio, then Build > Build APK(s)

To build via Codemagic:
1. Upload this ZIP to Codemagic (https://codemagic.io) as an Upload Project
2. Run the `debug-android-workflow`
3. Download the APK from Artifacts
