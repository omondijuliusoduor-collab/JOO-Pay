# JOO Pay — Capacitor + Next.js Prototype (Simulated live trips)

This package prepares a Next.js web app configured for Capacitor so you can build an Android APK with Android Studio.
It includes a web prototype that **simulates live bus trips** (CBD → Westlands → Kangemi → Udhiru) and preloaded sample transactions.

**Important:** I cannot bundle Android Studio inside this ZIP. You must install Android Studio on your machine (link below).
This package *does* include everything needed to generate the Android project via Capacitor and open it in Android Studio.

---
## Quick web test (on your computer)
1. Unzip this folder `joo-pay-capacitor.zip`.
2. Open terminal in the folder.
3. Run:
   ```bash
   npm install
   npm run dev
   ```
4. Open `http://localhost:3000` in your browser (Passenger view).
   - Admin view: http://localhost:3000/admin
   - The app simulates the bus moving along stops automatically (every ~7 seconds).

## To create Android project and build APK (Android Studio required)
1. Install Node.js LTS: https://nodejs.org/
2. Install Android Studio: https://developer.android.com/studio (follow installation guide for your OS)
3. In the project folder run:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap copy android
   ```
   - `npx cap add android` generates the `android/` native project. If it errors because Android SDK not found, install Android Studio first and ensure SDK/command-line tools configured.
4. Open the generated Android project in Android Studio:
   - `File > Open` → choose `<project-folder>/android`
   - Let Gradle sync (may take a few minutes).
5. Build APK:
   - `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - Android Studio will show the APK path; transfer it to your phone and install.

## Notes about simulation & behavior
- The web prototype automatically advances the **bus position** between stops every ~7 seconds to simulate a live trip.
- Fare is calculated based on current bus position and passenger boarding stop (boarding later → lower fare).
- Payments are **simulated** (M-Pesa mock PIN, Card, Paybill). No real money is processed.
- Each trip generates a unique Trip ID and QR payload; QR per trip is unique and expires when the trip ends in the simulation.

## Need help?
If you'd like, I can:
- Deploy the app to Vercel for instant phone testing (no install needed).
- Generate the Android project on my side and provide the `android/` folder ready (I can create the generated android/ folder if you prefer).

Created: 2025-09-30
