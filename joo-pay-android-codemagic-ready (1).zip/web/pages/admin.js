import React from 'react';

export default function Admin(){
  const now = new Date();
  const trips = [
    { id: 'TRIP_A', route: 'Nairobi CBD -> Udhiru', passengers: 12, revenue: 960 },
    { id: 'TRIP_B', route: 'Nairobi CBD -> Westlands', passengers: 8, revenue: 480 },
    { id: 'TRIP_C', route: 'Kangemi -> Udhiru', passengers: 5, revenue: 200 }
  ];

  const transactions = [
    { id: 'TX1', trip:'TRIP_A', boarding:'CBD', amount:80, method:'mpesa', time: new Date(now.getTime()-3600000).toISOString() },
    { id: 'TX2', trip:'TRIP_A', boarding:'Westlands', amount:60, method:'card', time: new Date(now.getTime()-3500000).toISOString() },
    { id: 'TX3', trip:'TRIP_B', boarding:'Kangemi', amount:40, method:'paybill', time: new Date(now.getTime()-1800000).toISOString() }
  ];

  const totalRevenue = trips.reduce((s,t)=>s+t.revenue,0);
  const commission = transactions.length * 5;

  return (
    <div style={{padding:24,fontFamily:'sans-serif'}}>
      <header style={{display:'flex',justifyContent:'space-between'}}>
        <h1>JOO Pay — Admin</h1>
        <a href="/">Passenger</a>
      </header>
      <div style={{marginTop:16}}>
        <div>Total Revenue: KES {totalRevenue}</div>
        <div>Your Commission: KES {commission}</div>
      </div>

      <h3 style={{marginTop:12}}>Trips</h3>
      <ul>
        {trips.map(t=> <li key={t.id}>{t.id} — {t.route} — passengers:{t.passengers} — revenue: KES {t.revenue}</li>)}
      </ul>

      <h3 style={{marginTop:12}}>Recent Transactions</h3>
      <table border="1" cellPadding="6">
        <thead><tr><th>Tx</th><th>Trip</th><th>Boarding</th><th>Amt</th><th>Method</th><th>Time</th></tr></thead>
        <tbody>
          {transactions.map(tx=> <tr key={tx.id}><td>{tx.id}</td><td>{tx.trip}</td><td>{tx.boarding}</td><td>KES {tx.amount}</td><td>{tx.method}</td><td>{new Date(tx.time).toLocaleString()}</td></tr>)}
        </tbody>
      </table>
    </div>
  );
}
