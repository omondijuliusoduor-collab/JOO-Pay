Android Studio project scaffold for JOO Pay (Debug build)

How to open and build APK:
1. Install Android Studio (https://developer.android.com/studio).
2. Open Android Studio -> File -> Open -> select this 'android' folder.
3. Let Android Studio sync Gradle (it may prompt to install SDK components).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. After build completes, locate the APK path in the Build output and install on your device.

Notes:
- If Gradle wrapper is missing, Android Studio will prompt to download it; accept the prompt.
- This scaffold uses Capacitor Android runtime; when you open, Android Studio may request internet to download dependencies.
